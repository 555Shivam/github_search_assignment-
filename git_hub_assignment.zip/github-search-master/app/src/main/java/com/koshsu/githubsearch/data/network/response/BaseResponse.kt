package com.koshsu.githubsearch.data.network.response

/**
 * Base response interface for remote api calls
 */
interface BaseResponse